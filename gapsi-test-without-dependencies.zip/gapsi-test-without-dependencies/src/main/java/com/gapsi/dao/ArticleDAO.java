package com.gapsi.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.gapsi.entity.Article;

@Transactional
@Repository
public class ArticleDAO implements IArticleDAO {
	@PersistenceContext	
	private EntityManager entityManager;	
	
	@Override
	public Article getArticleById(int id) {
		return entityManager.find(Article.class, id);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Article> getAllArticles() {
		String queryStr = "FROM Article as a ORDER BY a.id";
		return (List<Article>) entityManager.createQuery(queryStr).getResultList();
	}
	
	@Override
	public void addArticle(Article article) {
		entityManager.persist(article);
	}
	
	@Override
	public void updateArticle(Article article) {
		Article updatedArticle = getArticleById(article.getId());
		updatedArticle.setDescription(article.getDescription());
		updatedArticle.setModel(article.getModel());
		entityManager.flush();
	}
	
	@Override
	public void deleteArticle(int id) {
		entityManager.remove(getArticleById(id));
	}
	
	@Override
	public boolean existsArticle(String name) {
		String queryStr = "FROM Article as a WHERE a.name = :name";
		int count = entityManager.createQuery(queryStr).setParameter("name", name).getResultList().size();
		return count > 0 ? true : false;
	}
} 
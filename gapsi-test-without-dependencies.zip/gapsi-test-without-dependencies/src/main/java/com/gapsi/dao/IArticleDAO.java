package com.gapsi.dao;

import java.util.List;
import com.gapsi.entity.Article;

public interface IArticleDAO {
	
	Article getArticleById(int id);
    List<Article> getAllArticles();
    void addArticle(Article article);
    void updateArticle(Article article);
    void deleteArticle(int id);
    boolean existsArticle(String name);
    
}
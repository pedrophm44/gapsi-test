package com.gapsi.restClientExample;

import java.math.BigDecimal;
import java.net.URI;
import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.gapsi.entity.Article;

public class RestClientExample {
	
	private static final String BASE_URL = "http://localhost:8080/";
	
	private HttpHeaders headers;
	private RestTemplate restTemplate;
    
	public RestClientExample() {
		headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_JSON);
        restTemplate = new RestTemplate();
	}
	
    public void getArticleById(Integer id) {
    	System.out.println("Get article: "+id);
    	if ( id != null ) {
	    	HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
	        ResponseEntity<Article> responseEntity = restTemplate.exchange(BASE_URL + "article/{id}", HttpMethod.GET, requestEntity, Article.class, id);
	        Article article = responseEntity.getBody();
	        printArticle(article);
    	} else
    		System.out.println("Error: Invalid article id.");
    }
    
    public void getAllArticles() {
    	System.out.println("Showing articles:");
        HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
        ResponseEntity<Article[]> responseEntity = restTemplate.exchange(BASE_URL + "articles", HttpMethod.GET, requestEntity, Article[].class);
        Article[] articles = responseEntity.getBody();
        if ( articles != null && articles.length > 0 )
        	Arrays.asList(articles).forEach(article -> {printArticle(article);});
        else System.out.println("There are not articles");
    }
    
    @SuppressWarnings("unused")
	public void addArticle(Article article) {
    	System.out.println("Add article:");
    	if ( article != null ) {
			HttpEntity<Article> requestEntity = new HttpEntity<Article>(article, headers);
	        URI uri = restTemplate.postForLocation(BASE_URL + "article", requestEntity);
        	System.out.println("Article "+article.getName()+" was created");
    	} else
    		System.out.println("Error: Article could not be created. Invalid article.");
    }
    
    public void updateArticle(Article article) {
    	System.out.println("Update article:");
    	if ( article != null ) {
	        HttpEntity<Article> requestEntity = new HttpEntity<Article>(article, headers);
	        restTemplate.put(BASE_URL + "article", requestEntity);
	        System.out.println("Article "+article.getName()+" (Id "+article.getId()+") was updated");
    	} else
    		System.out.println("Error: Article could not be updated. Invalid article.");
    }
    
    public void deleteArticle(Integer id) {
    	System.out.println("Delete article: "+id);
    	if ( id != null ) {
		    HttpEntity<Article> requestEntity = new HttpEntity<Article>(headers);
	        restTemplate.exchange(BASE_URL + "article/{id}", HttpMethod.DELETE, requestEntity, Void.class, id);
	        System.out.println("Article with Id "+id+" was deleted");
    	} else
    		System.out.println("Error: Article could not be deleted. Invalid id.");    
    }
    
    public void printArticle(Article article) {
    	if ( article != null )
	    	System.out.println(
				"Id: "+article.getId()+", " + 
				"Name: "+article.getName() +", " +
				"Description: "+article.getDescription() +", " +
				"Price: "+article.getPrice() +", " +
				"Model: "+article.getModel()
			);
    }
    
    public static void main(String args[]) {
    	RestClientExample client = new RestClientExample();
    	System.out.println("Starting REST Client Example...");
    	
    	client.getAllArticles();
    	
        Article article = new Article();
		article.setName("Product One");
		article.setDescription("Description for product one");
		article.setPrice(new BigDecimal(10.5));
		article.setModel("Model A");
		client.addArticle(article);
		
		article = new Article();
		article.setName("Product Two");
		article.setDescription("Description for product two");
		article.setPrice(new BigDecimal(22.0));
		article.setModel("Model B");
		client.addArticle(article);
		
		article = new Article();
		article.setName("Product Three");
		article.setDescription("Description for product three");
		article.setPrice(new BigDecimal(31.99));
		article.setModel("Model A");
		client.addArticle(article);
		
		client.getAllArticles();
    	
		article.setId(3);
		article.setDescription("Awesome product three (Updated)");
		article.setModel("Model C");
		client.updateArticle(article);
		
		client.getAllArticles();
		
		client.deleteArticle(article.getId());
		
		client.getAllArticles();
		System.out.println("Ending REST Client Example.");
    }    
}
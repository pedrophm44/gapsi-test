package com.gapsi.service;

import java.util.List;
import com.gapsi.entity.Article;

public interface IArticleService {
	
	Article getArticleById(int id);
    List<Article> getAllArticles();
    boolean addArticle(Article article);
    void updateArticle(Article article);
    void deleteArticle(int id);
}
/**
 * 
 */
/**
 * @author pedro
 *
 */
package com.gapsi.entity;